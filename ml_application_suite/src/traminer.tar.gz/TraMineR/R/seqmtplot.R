## ============================================
## PLOT OF THE STATES DISTRIBUTION BY TIME UNIT
## ============================================

seqmtplot <- function(seqdata, group = NULL, main = "auto", ...) {
	seqplot(seqdata, group=group, type="mt", main=main, ...)

}
