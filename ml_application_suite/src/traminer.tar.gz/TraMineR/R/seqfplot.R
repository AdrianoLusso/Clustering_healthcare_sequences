## ================================
## PLot of the sequences frequency
## ================================

seqfplot <- function(seqdata, group = NULL, main = "auto", ...) {
	seqplot(seqdata, group=group, type="f", main=main, ...)
}
