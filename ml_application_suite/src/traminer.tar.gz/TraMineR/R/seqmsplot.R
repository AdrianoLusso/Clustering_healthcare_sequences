## ====================================
## PLOT OF THE SEQUENCE OF MODAL STATES
## ====================================

seqmsplot <- function(seqdata, group = NULL, main = "auto", ...) {
	seqplot(seqdata, group=group, type="ms", main=main, ...)
}
