## ======================
## Plotting entropy index
## ======================

seqHtplot <- function(seqdata, group = NULL, main = "auto", ...) {
	seqplot(seqdata, group=group, type="Ht", main=main, ...)
}
